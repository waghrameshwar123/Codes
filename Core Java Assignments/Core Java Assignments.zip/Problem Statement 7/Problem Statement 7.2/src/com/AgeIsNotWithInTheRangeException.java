package com;

public class AgeIsNotWithInTheRangeException extends Exception {

}
