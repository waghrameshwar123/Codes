package com;

public class CounterThred {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Counter counter = new Counter(50);

		counter.run();

	}

}
